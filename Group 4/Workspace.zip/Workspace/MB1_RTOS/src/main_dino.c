#include "mb1.h"
#if ( mainSELECTED_APPLICATION == 1 )
/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
/* Final project includes. */
#include "elt3017_draw.h"

#define ENABLE_QUEUE 0
#define ENABLE_TIMER 0

#define frame_index  0
#define line_val 375		//duong bottom line
#define val_bg 0x00
#define DAN_BOSS_NUM 3
#define DAN_NUM 6

//#define myabs(x,y) ((x>y)? (x-y):(y-x))
#define myabs(x,y) (((long)x>(long)y)? ((long)x-(long)y):((long)y-(long)x))

static void ButtonReadTask( void *pvParameters );
static void DrawTask( void *pvParameters );
static void HitCheckTask( void *pvParameters );
static void Boss(void *pvParameters);


void init_game();

static TaskHandle_t xButtonReadTask;
static TaskHandle_t xDrawTask;
static TaskHandle_t xHitCheckTask;
static TaskHandle_t xBoss;


#if(ENABLE_QUEUE == 1)
static QueueHandle_t xQueue = NULL;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;
#endif
#if(ENABLE_TIMER == 1)
#define TIMER_ID	1
#define DELAY_100_SECONDS	100000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	99
static void vTimerCallback( TimerHandle_t pxTimer );
static TimerHandle_t xTimer = NULL;
#endif

/* For GPIO */
#define GPIO_DEVICE_ID		XPAR_GPIO_0_DEVICE_ID
#define GPIO_CHANNEL1		1
#define BUTTON_CHANNEL	 1	/* Channel 1 of the GPIO Device */
XGpio Gpio;

/* Pressed button */
u32 pressed_dat, prev_dat = 0;

/* game variables */
int movex, movey, movey1 = -10;
struct Dino MyDino;
struct Dino MyBoss;
struct Tree DanBoss[DAN_BOSS_NUM];
struct Dan MyDan[DAN_NUM];
int speed = 0;
xSemaphoreHandle GameOver_signal = 0;
int hit,score;
int didprint = 0;
int n =0,a = 0, b = 0, HP_BOSS=0;


int main( void )
{
	#if(ENABLE_TIMER == 1)
	const TickType_t x1seconds = pdMS_TO_TICKS( DELAY_1_SECOND);
	#endif
	XGpio_Initialize(&Gpio, GPIO_DEVICE_ID);
	xil_printf( "Hey, we are doing a FreeRTOS program!\r\n" );
	init_game();
	vSemaphoreCreateBinary(GameOver_signal);

	xTaskCreate( DrawTask,
				 ( const char * ) "Draw",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY,
				 &xDrawTask );
	xTaskCreate( ButtonReadTask,
				 ( const char * ) "Button",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 configMAX_PRIORITIES - 1,
				 &xButtonReadTask );
	xTaskCreate( HitCheckTask,
				 ( const char * ) "Hit",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 configMAX_PRIORITIES - 2,
				 &xHitCheckTask );
	xTaskCreate ( Boss,
				( const char *)"Boss",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY+2,
				&xBoss );
//	xTaskCreate (Dan,
//				( const char *) "Hit",
//				configMINIMAL_STACK_SIZE,
//				NULL,
//				tskIDLE_PRIORITY,
//				&xDan );
	#if(ENABLE_QUEUE == 1)
	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
							sizeof( HWstring ) );	/* Each space in the queue is large enough to hold a uint32_t. */
	configASSERT( xQueue );
	#endif

	#if(ENABLE_TIMER == 1)
	xTimer = xTimerCreate( (const char *) "Timer",
							x1seconds,
							pdTRUE,
							(void *) TIMER_ID,
							vTimerCallback);
	configASSERT( xTimer );
	xTimerStart( xTimer, 0 );
	#endif

	vTaskStartScheduler();

	for( ;; );
}

static void ButtonReadTask( void *pvParameters )
{

	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 33 );
	xLastWakeTime = xTaskGetTickCount();
	for( ;; )
	{

		if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
//			xil_printf("buttonRxTask: Missed deadline.\r\n");
			xLastWakeTime = xTaskGetTickCount();
		}
		pressed_dat = 511 & XGpio_DiscreteRead(&Gpio, BUTTON_CHANNEL); // only take last 9 bit
		if (prev_dat != pressed_dat && pressed_dat != (u32)0) {
			if (pressed_dat & 0x10) {
				movex =0;

				movey = -8;

			}
			else if (pressed_dat & 0x40) {movex =0;
							movey = 8;


			}
			else if (pressed_dat & 0x80){
				a = 0;
				for (int i = 0; i < DAN_NUM; i++){
				DrawARectMemcpy(0, RESOLUTION_640x480, (250-i*15-10)*640, 10,10 , 0xff0000);
				DrawARectMemcpy(0, RESOLUTION_640x480, (250-i*15-10)*640+150, 10,10 , 0xff0000);
				}
			}
			else if (pressed_dat & 0x20) {
				if (a < DAN_NUM) {
					MyDan[a].x = 230;
					MyDan[a].speed = 8;
					MyDan[a].y = MyDino.Pindex/640+5;
					MyDan[a].height = 5;
					MyDan[a].dkien = 0;
					a++;

					b =1;
					}
			}
			else if (pressed_dat & 0x100) {
				xil_printf("we restart/start the game!\r\n");
				#ifdef USE_MEMCPY
					DrawARectMemset(0, RESOLUTION_640x480,0,640,500,val_bg);
				#endif
				init_game();
				DrawARectMemcpy(frame_index, RESOLUTION_640x480, MyDino.Pindex, MyDino.Dim, MyDino.Dim, SQR_COLOR);
				DrawARectMemcpy(frame_index, RESOLUTION_640x480, MyBoss.Pindex, MyBoss.Dim, MyBoss.Dim, 0xffffff);
				speed= 3;
			}
		}
		prev_dat = pressed_dat;
		vTaskDelayUntil( &xLastWakeTime, xPeriod );
	}
}
static void DrawTask( void *pvParameters )
{
	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 33 );
	xLastWakeTime = xTaskGetTickCount();
	for( ;; )
		{
//		xSemaphoreGive(GameOver_signal);

		if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
//			xil_printf("buttonRxTask: Missed deadline.\r\n");
			xLastWakeTime = xTaskGetTickCount();
		}
		if (b=1) {
			DrawARectMemcpy(0, RESOLUTION_640x480, (250-(DAN_NUM-a)*15-10)*640+150, 10,10 , 0x000000);

			b=0;
		}

		if (hit ==0) {
			for (int indx = 0; indx < DAN_BOSS_NUM; indx++) {
				MoveDanBoss(frame_index, &DanBoss[indx].X,&DanBoss[indx].y, DanBoss[indx].height, &DanBoss[indx].speed, MyBoss.Pindex/640+10);
			}
			for (int indx = 0; indx < DAN_NUM; indx++) {
				MoveDan(frame_index, &MyDan[indx].x,&MyDan[indx].y, MyDan[indx].height, &MyDan[indx].speed, MyDino.Pindex/640+10, MyDan[indx].dkien);
			}
//			xil_printf(" xdan = %d, ydan =%d\n\r",MyDan[a-1].x,MyDan[a-1].y);
			if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
				xLastWakeTime = xTaskGetTickCount();
			}
			if (MyDino.Pindex/640 <= 80 && movey < 0)
				movey = 0;
			if (MyDino.Pindex/640 >= 245 - MyDino.Dim && movey > 0)
				movey = 0;
			if (movey < 0) {
				MoveDinoUpDown(frame_index, &MyDino.Pindex, MyDino.Dim,  movey/2);
				movey++;
			} else
			if ( movey > 0) {
				MoveDinoUpDown(frame_index, &MyDino.Pindex, MyDino.Dim,   movey/2);
				movey--;
			}

		}
		else if (hit ==2 ){

			DrawARectMemcpy(0, RESOLUTION_640x480, (250-(HP_BOSS)*30)*640+625, 10,30 , 0x000000);
			if ( HP_BOSS == 6){
				hit = 1;
			}
			else {
			hit =0;
			}

		}
		vTaskDelayUntil( &xLastWakeTime, xPeriod );
	}
}


static void HitCheckTask( void *pvParameters ){

	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 33 );
	xLastWakeTime = xTaskGetTickCount();
	int DinoX, DinoY;
	for( ;; )
		{
//		xSemaphoreTake(GameOver_signal,portMAX_DELAY);
		if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
			xLastWakeTime = xTaskGetTickCount();
		}
		taskENTER_CRITICAL();
		DinoY = MyDino.Pindex/640;
		DinoX = MyDino.Pindex%640;

		for (int indx = 0; indx < DAN_BOSS_NUM; indx++) {
			if (myabs(DanBoss[indx].X , DinoX)< DanBossWidth && myabs(DanBoss[indx].y , DinoY) < DanBoss[indx].height) {

					if (didprint == 0) {
						xil_printf("Hits!");
						xil_printf("Dino at %ld, x = %d, y = %d\r\n", MyDino.Pindex, DinoX, DinoY);
						xil_printf("Tree at x = %d, h = %d\r\n", DanBoss[indx].X, DanBoss[indx].y);
						didprint = 1;
					}
				hit = 1;
				}
			for (int indx1 = 0; indx1 < a; indx1 ++){
				if (myabs(DanBoss[indx].X , MyDan[indx1].x) < DanBossWidth && myabs(DanBoss[indx].y,MyDan[indx1].y) < DanBoss[indx].height){
//					DrawARectMemcpy(frame_index, RESOLUTION_640x480, ToPindex(MyDan[indx1].x,MyDan[indx1].y), DanWidth,MyDan[indx1].height , 0x000000);
//					MyDan[indx1].x =640;
					MyDan[indx1].dkien = 1;

//					xil_printf("Danx = %d/r , danx = %d/r/n",MyTree[indx].y,MyDan[indx1].y);
				}
			}
		}
		taskEXIT_CRITICAL();
		vTaskDelayUntil( &xLastWakeTime, xPeriod );
		}
	}

//}
static void Boss (void *pvParameters){

	TickType_t xLastWakeTime;
		const TickType_t xPeriod = pdMS_TO_TICKS( 20 );
		xLastWakeTime = xTaskGetTickCount();
		int tocdoban = 0;
		int BossX,BossY;
		for( ;; )
			{
	//		xSemaphoreGive(GameOver_signal);

			if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
	//			xil_printf("buttonRxTask: Missed deadline.\r\n");
				xLastWakeTime = xTaskGetTickCount();
			}
			BossY = MyBoss.Pindex/640;
			BossX = MyBoss.Pindex%640;
			if (hit == 0){
				if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
								xLastWakeTime = xTaskGetTickCount();
			}
//
			for (int indx =0; indx < DAN_NUM; indx++){
				if (hit!=2 && 549 < MyDan[indx].x && MyDan[indx].x <600 && BossY - DanWidth + 1 < MyDan[indx].y && MyDan[indx].y  <BossY +DanWidth-1+20) {
					hit =2;
					HP_BOSS++;
					MyDan[indx].x = 700;
					xil_printf("Bossy=%d\r\n",HP_BOSS);
				}
//
			}
//			}
			MoveDinoUpDownBoss(frame_index, &MyBoss.Pindex, MyBoss.Dim,  movey1/2);
			if (movey1 <0 && MyBoss.Pindex/640 <= 80){
				movey1 = 2;
			}
			if (movey1 >0 && MyBoss.Pindex/640 >= 250 -25 ){
				movey1 = -2;
			}

			if (n < DAN_BOSS_NUM && tocdoban%12 ==0){
			DanBoss[n].X = 550;
			DanBoss[n].speed = 8;
			DanBoss[n].y = MyBoss.Pindex/640;
			DanBoss[n].height = 10;
			n ++;
			}
			tocdoban++;

			}

			vTaskDelayUntil( &xLastWakeTime, xPeriod );

		}
			}
#if(ENABLE_TIMER == 1)
/*-----------------------------------------------------------*/
static void vTimerCallback( TimerHandle_t pxTimer )
{
	long lTimerId;
	configASSERT( pxTimer );
	lTimerId = ( long ) pvTimerGetTimerID( pxTimer );
	if (lTimerId != TIMER_ID) {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}
}
#endif
void init_game(){
	a = 0;
	b = 0;
	n = 0;
	HP_BOSS =0;
	hit = 0;
	MyDino.Pindex = ToPindex(210,150);
	MyDino.Dim = 10;
	MyBoss.Pindex = ToPindex(550,150);
	MyBoss.Dim = 20;
	didprint = 0;
	for (int indx = 0; indx < DAN_BOSS_NUM; indx++) {
		DanBoss[indx].X = 750;
		DanBoss[indx].speed = 0;
		DanBoss[indx].y = MyBoss.Pindex/640+10;
		DanBoss[indx].height = 10;
	}
	DrawARectMemcpy(0, RESOLUTION_640x480, (48+25)*640, 320,2 , 0x00ff12);
	DrawARectMemcpy(0, RESOLUTION_640x480, (48+25)*640+320, 320,2 , 0x00ff12);
	DrawARectMemcpy(0, RESOLUTION_640x480, 251*640, 320,2 , 0x00ff12);
	DrawARectMemcpy(0, RESOLUTION_640x480, 251*640+320, 320,2 , 0x00ff12);
	DrawARectMemcpy(0, RESOLUTION_640x480, 75*640+190, 2,175 , 0x00ff12);
	DrawARectMemcpy(0, RESOLUTION_640x480, 75*640+625, 10,175 , 0xff0000);
	DrawARectMemcpy(0, RESOLUTION_640x480, 75*640+623, 2,175 , 0x00ff12);
	for (int i = 0; i < DAN_NUM; i++){
	DrawARectMemcpy(0, RESOLUTION_640x480, (250-i*15-10)*640+150, 10,10 , 0xff0000);
	}
}
#endif
