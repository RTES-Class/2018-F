
//Vi du ve score nam trong HitCheckTask
static void HitCheckTask(void *pvParameters)
{
	for (;;)
	{		
		if (xTaskGetTickCount() - xLastWakeTime > xPeriod)
		{
			}
		
		for ()
		{
			if ()
			{
				if ()
				{
					
				}
				
			if (DinoX + MyDino.Dim >= MyTree[indx].X && DinoX <= MyTree[indx].X + TreeWidth)
			{
				if ()
				{
					if ()
					{
						
					}

					
				}
				else
				{
					score++;					
					scoreNumber((score+1)/5 % 10, 130, 200);
					//xil_printf("%d", score % 10);
					scoreNumber((score+1)/5 / 10, 100, 200);
					//xil_printf("%d\r\n", score / 10);
				}
			}
		}
	}
}


/** Cac gia tri edgeNumber      do rong cua mot thanh             
 *              widthNumber     do rong cua so     
 *              heightNumber    Chieu cao cua so / 2
 * Co the them cac gia tri nay nhu la parameter hoac #define o dau chuong trinh
 * @param number so can in ra
 * @param xPosition vi tri cua so so voi man hinh
 * @param yPosition vi tri cua so so voi man hinh
 * 
 * @return none
 */
void scoreNumber(int number, int xPosition, int yPosition)
{
	unsigned int pixel = ToPindex(xPosition, yPosition);
	int value;
	int valueArray[10] = {0b0111111, 0b0000110, 0b1011011, 0b1001111, 0b1100110, 0b1101101, 0b1111101, 0b0000111, 0b1111111, 0b1101111};
	value = valueArray[number];
	int fidx = 0;
	//a
	if (value & 0x01)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + edgeNumber, widthNumber, edgeNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + edgeNumber, widthNumber, edgeNumber, 0x000000);
	}

	//b
	if (value & 0x02)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(widthNumber + edgeNumber,edgeNumber), edgeNumber, heightNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(widthNumber + edgeNumber,edgeNumber), edgeNumber, heightNumber, 0x000000);
	}

	//c
	if (value & 0x04)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(widthNumber + edgeNumber, (heightNumber+edgeNumber*2)), edgeNumber, heightNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(widthNumber + edgeNumber, (heightNumber+edgeNumber*2)), edgeNumber, heightNumber, 0x000000);
	}

	//d
	if (value & 0x08)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (edgeNumber+heightNumber+edgeNumber+heightNumber)), widthNumber, edgeNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber * 2+edgeNumber*2)), widthNumber, edgeNumber, 0x000000);
	}

	//e
	if (value & 0x10)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(0, (heightNumber+edgeNumber*2)), edgeNumber, heightNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(0, (heightNumber+edgeNumber*2)), edgeNumber, heightNumber, 0x000000);
	}

	//f
	if (value & 0x20)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(0,edgeNumber), edgeNumber, heightNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(0,edgeNumber), edgeNumber, heightNumber, 0x000000);
	}

	//g
	if (value & 0x40)
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (edgeNumber+ heightNumber)), widthNumber, edgeNumber, 0xff0000);
	else
	{
		DrawARectMemcpy(fidx, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber+edgeNumber)), widthNumber, edgeNumber, 0x000000);
	}
}