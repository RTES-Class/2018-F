/******************************************************************************/
/***************************** Include Files **********************************/
/******************************************************************************/
#include <stdio.h>
//#include "xil_io.h"
#include "xparameters.h"
#include "xil_cache.h"
#include "math.h"
#include "sleep.h"
#include "elt3017_draw.h"
#include "mb1.h"
#include "stdlib.h"
/*****************************************************************************/
/******************* Macros and Constants Definitions ************************/
/*****************************************************************************/
#define MIN(x, y)				(x < y ? x : y)
#define MAX(x, y) 				(x > y ? x : y)
#define DIV_ROUND_UP(x,y)		(((x) + (y) - 1) / (y))
#define DIV_ROUND_CLOSEST(x, y)	(unsigned long)(((double)x / y) + 0.5)
#define CLAMP(val, min, max)	(val < min ? min : (val > max ? max :val))

const u32 frame_base[3] = {VIDEO_BASEADDR,VIDEO_BASEADDR2,VIDEO_BASEADDR3};

enum detailedTimingElement
{
	PIXEL_CLOCK,
	H_ACTIVE_TIME,
	H_BLANKING_TIME,
	H_SYNC_OFFSET,
	H_SYNC_WIDTH_PULSE,
	V_ACTIVE_TIME,
	V_BLANKING_TIME,
	V_SYNC_OFFSET,
	V_SYNC_WIDTH_PULSE
};

static const unsigned long detailedTiming[7][9] =
{
	{25180000, 640, 144, 16, 96, 480, 29, 10, 2},
	{40000000, 800, 256, 40, 128, 600, 28, 1, 4},
	{65000000, 1024, 320, 136, 24, 768, 38, 3, 6},
	{74250000, 1280, 370, 110, 40, 720, 30, 5, 5},
	{84750000, 1360, 416, 136, 72, 768, 30, 3, 5},
	{108000000, 1600, 400, 32, 48, 900, 12, 3, 6},
	{148500000, 1920, 280, 44, 88, 1080, 45, 4, 5}
};
#ifndef USE_MEMCPY
void DrawARect(int fidx, char resolution,unsigned long pixel, int w, int h, u32 val)
{
	unsigned long pindex = pixel;
	unsigned short horizontalActiveTime = detailedTiming[resolution][H_ACTIVE_TIME];
	for (int i=0; i<h;i++)
	{
		for (int j=0; j <w; j++)
		{
			pindex++;
			Xil_Out32((frame_base[fidx]+(pindex<<2)), (val & 0xffffff));
		}
		pindex=pindex+horizontalActiveTime-w;
	}

	Xil_DCacheFlush();
}
#else
#define DrawARect RENAME(DrawARectMemcpy)

void DrawARectMemcpy(int fidx, char resolution,unsigned long pixel, int w, int h, u32 val){
	int i;
	u32 pindex = (u32) (pixel*4)+ frame_base[fidx];
	unsigned short horizontalActiveTime = detailedTiming[(int) resolution][(int) H_ACTIVE_TIME];
	u32 * line;
	line = malloc(w*(4));
	for (i = 0; i < w; i++)
	{
	  *(u32*)(line + i) = val;
	}
	for (i = 0; i < h; i++)
	{
	  memcpy((void *)pindex, line, w*(4) );
	  pindex=pindex+horizontalActiveTime*(4);
	}
	free(line);
}

void DrawACirMemcpy(int fidx, char resolution, unsigned long pixel, int r, u32 val)
{
	int x = r - 1;
	int y = 0;
	int dx = 1;
	int dy = 1;
	int err = dx - (r << 1);

	u32 pindex = (u32) (pixel*4)+ frame_base[fidx];
	unsigned short horizontalActiveTime = detailedTiming[(int) resolution][(int) H_ACTIVE_TIME];
	u32 * line;
	line = malloc(4);

	while (pixel%640 >= pixel/640)
	{
		memcpy((void *)(((pindex%640)+x)+((pindex/640)+y)*640), line, 4);
		memcpy((void *)(((pindex%640)+y)+((pindex/640)+x)*640), line, 4);
		memcpy((void *)(((pindex%640)-y)+((pindex/640)+x)*640), line, 4);
		memcpy((void *)(((pindex%640)-x)+((pindex/640)+y)*640), line, 4);
		memcpy((void *)(((pindex%640)-x)+((pindex/640)-y)*640), line, 4);
		memcpy((void *)(((pindex%640)-y)+((pindex/640)-x)*640), line, 4);
		memcpy((void *)(((pindex%640)+y)+((pindex/640)-x)*640), line, 4);
		memcpy((void *)(((pindex%640)+x)+((pindex/640)-y)*640), line, 4);

		pindex=pindex+horizontalActiveTime*(4);
		if (err <= 0)
		{
			y++;
			err += dy;
			dy += 2;
		}

		if (err > 0)
		{
			x--;
			dx += 2;
			err += dx - (r << 1);
		}
	}
}

void DrawARectMemset(int fidx, char resolution,unsigned long pixel, int w, int h, u32 val){
	int i;
	u32 pindex = (u32) (pixel*4)+ frame_base[fidx];
	unsigned short horizontalActiveTime = detailedTiming[(int) resolution][(int) H_ACTIVE_TIME];
	for (i = 0; i < h; i++)
	{
	  memset((void *)pindex, val, w*(4) );
	  pindex=pindex+horizontalActiveTime*(4);	}
}
#endif

void MoveSnakeUpDown(int fidx, unsigned long * pixel, int size, int movey)
{
	*pixel = *pixel + movey * 640;
}

void MoveSnakeLeftRight(int fidx, unsigned long * pixel, int size, int movex)
{
	*pixel = *pixel + movex;
}

void DrawBound()
{
	DrawARectMemset(0, RESOLUTION_640x480,0,640,480,0x000000);
	DrawARectMemcpy(0, RESOLUTION_640x480,0,640,20,val_bound);
	DrawARectMemcpy(0, RESOLUTION_640x480,0,20,480,val_bound);
	DrawARectMemcpy(0, RESOLUTION_640x480,640*460,640,20,val_bound);
	DrawARectMemcpy(0, RESOLUTION_640x480,620,20,480,val_bound);
}
