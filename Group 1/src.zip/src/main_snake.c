#include "mb1.h"
#if ( mainSELECTED_APPLICATION == 1 )
/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
/* Final project includes. */
#include "elt3017_draw.h"

#define ENABLE_QUEUE 0
#define ENABLE_TIMER 0

#define frame_index  0
#define line_val 0x01f104

#define TREE_NUM 4
int SPEED = 10;
#define SIZE_SNAKE 10

#define edgeNumber 2
#define widthNumber 5
#define heightNumber 5

static void ButtonReadTask( void *pvParameters );
static void DrawTask( void *pvParameters );
static void HitCheckTask( void *pvParameters );
static void vSetupGPIOInterrupt();
void DrawARandomNode(int position);
void scoreNumber(int  number, int xPosition, int yPosition);
static void vButtonReadISR();
int checkGen(struct Dino * p, unsigned long pixel);

void DrawARandomNode();
void init_game();
struct Dino * MySnake;

static TaskHandle_t xButtonReadTask;
static TaskHandle_t xDrawTask;
static TaskHandle_t xHitCheckTask;

#if(ENABLE_QUEUE == 1)
static QueueHandle_t xQueue = NULL;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;
#endif
#if(ENABLE_TIMER == 1)
#define TIMER_ID	1
#define DELAY_100_SECONDS	100000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	99
static void vTimerCallback( TimerHandle_t pxTimer );
static TimerHandle_t xTimer = NULL;
#endif

/* For GPIO */
#define GPIO_DEVICE_ID		XPAR_GPIO_0_DEVICE_ID
#define GPIO_CHANNEL1		1
#define BUTTON_CHANNEL	 1	/* Channel 1 of the GPIO Device */
XGpio Gpio;
static const unsigned long ulGPIOInputChannel = 1UL;

/* Pressed button */
u32 pressed_dat, prev_dat = 0;

/* game variables */

#define WEIGHT_WINDOW 640
#define HEIGHT_WINDOW 480

int movex, movey;
struct Dino Snake;
struct Tree Bound;
unsigned long position;
static int Size = 0;
static int Score = 0;
xSemaphoreHandle Button_signal = 0;

u32 Color[7] = {RED, YELLOW, GREEN, BLUE, VIOLET, WHITE, PURPLE};

int speed = 0;
xSemaphoreHandle GameOver_signal = 0;
int hit;

int main( void )
{
	MySnake = malloc(100*sizeof(struct Dino));
//	init_game();
//	DrawACirMemcpy(0, RESOLUTION_640x480, 100, 10, 0xFFFFFF);
	#if(ENABLE_TIMER == 1)
	const TickType_t x1seconds = pdMS_TO_TICKS( DELAY_1_SECOND);
	#endif
	DrawARectMemset(0, RESOLUTION_640x480,0,640,480,val_bg);
	XGpio_Initialize(&Gpio, GPIO_DEVICE_ID);
	xil_printf( "Hey, we are doing a FreeRTOS program!\r\n" );
	vSetupGPIOInterrupt();
	vSemaphoreCreateBinary(Button_signal);
	init_game();
	vSemaphoreCreateBinary(GameOver_signal);

	xTaskCreate( DrawTask,
				 ( const char * ) "Draw",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY+1,
				 &xDrawTask );
	xTaskCreate( ButtonReadTask,
				 ( const char * ) "Button",
				 (unsigned short) 5000,
				 NULL,
				 configMAX_PRIORITIES - 1,
				 &xButtonReadTask );
	xTaskCreate( HitCheckTask,
				 ( const char * ) "1",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY+ 2 ,
				 &xHitCheckTask );
	#if(ENABLE_QUEUE == 1)
	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
							sizeof( HWstring ) );	/* Each space in the queue is large enough to hold a uint32_t. */
	configASSERT( xQueue );
	#endif

	#if(ENABLE_TIMER == 1)
	xTimer = xTimerCreate( (const char *) "Timer",
							x1seconds,
							pdTRUE,
							(void *) TIMER_ID,
							vTimerCallback);
	configASSERT( xTimer );
	xTimerStart( xTimer, 0 );
	#endif

	vTaskStartScheduler();

	for( ;; );
}

static void ButtonReadTask( void *pvParameters )
{
	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 10 );
	xLastWakeTime = xTaskGetTickCount();
	for( ;; )
	{
//		if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
//			xil_printf("buttonRxTask: Missed deadline.\r\n");
//			xLastWakeTime = xTaskGetTickCount();
//		}

		if (xSemaphoreTake(Button_signal,portMAX_DELAY)) {
			pressed_dat = 511 & XGpio_DiscreteRead(&Gpio, BUTTON_CHANNEL);
			#if (DEBOUNCE_ENA == 1)// only take last 9 bit
			if (prev_dat != pressed_dat && pressed_dat != (u32)0) {
			#endif
				if (pressed_dat & 0x10) {
					movex = 0;

					if(movey != SPEED)
						movey = -SPEED;
				}
				else if (pressed_dat & 0x40) {
					movex = 0;

					if(movey != -SPEED)
						movey = SPEED;
				}
				else if (pressed_dat & 0x80){
					if (movex != SPEED)
						movex = -SPEED;

					movey = 0;
				}
				else if (pressed_dat & 0x20) {
					if (movex != -SPEED)
						movex = SPEED;

					movey = 0;
				}
				else if (pressed_dat & 0x100) {
					xil_printf("we restart/start the game!\r\n");
					#ifdef USE_MEMCPY
				//	DrawARectMemset(0, RESOLUTION_640x480,0,630,470,0x000000);
						DrawBound();
					#endif
						init_game();
				}
			#if (DEBOUNCE_ENA == 1)
			}
			prev_dat = pressed_dat;
			#endif
//		vTaskDelayUntil( &xLastWakeTime, xPeriod );
		}
	}
}
static void DrawTask( void *pvParameters )
{
//	TickType_t xLastWakeTime;
//	const TickType_t xPeriod = pdMS_TO_TICKS( 50 );
//	xLastWakeTime = xTaskGetTickCount();
	for( ;; )
	{
//		if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
//			xil_printf("buttonRxTask: Missed deadline.\r\n");
//			xLastWakeTime = xTaskGetTickCount();
//		}
		if (xSemaphoreTake(GameOver_signal,portMAX_DELAY)) {
		if (hit == 0) {
//			if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
//				xLastWakeTime = xTaskGetTickCount();
//			}

			if (movey != 0 && movex == 0)
			{
				DrawARectMemcpy(0, RESOLUTION_640x480, MySnake[Size-1].Pindex, SIZE_SNAKE, SIZE_SNAKE, 0x000000);

				if (Size > 0)
					for (int i = Size - 1; i > 0; i--)
					{
						MySnake[i].Pindex = MySnake[i - 1].Pindex;
					}

				MoveSnakeUpDown(frame_index, &MySnake[0].Pindex, MySnake[0].Dim, movey);

				DrawARectMemcpy(0, RESOLUTION_640x480, MySnake[0].Pindex, SIZE_SNAKE, SIZE_SNAKE, SQR_COLOR);
			}
			else if (movex != 0 && movey == 0)
			{
				DrawARectMemcpy(0, RESOLUTION_640x480, MySnake[Size-1].Pindex, SIZE_SNAKE, SIZE_SNAKE, 0x000000);

				if (Size > 0)
					for (int i = Size - 1; i > 0; i--)
					{
						MySnake[i].Pindex = MySnake[i - 1].Pindex;
					}

				MoveSnakeLeftRight(frame_index, &MySnake[0].Pindex, MySnake[0].Dim, movex);
				DrawARectMemcpy(0, RESOLUTION_640x480, MySnake[0].Pindex, SIZE_SNAKE, SIZE_SNAKE, SQR_COLOR);

			}
		}
		else if (hit == 1)
		{
			xil_printf("It's hit!");

			scoreNumber((Score)/10, 320, 0);
			scoreNumber((Score)%10, 333, 0);

	//		DrawARectMemcpy(0, RESOLUTION_640x480, position, SIZE_SNAKE, SIZE_SNAKE, 0x000000);
			DrawARectMemcpy(0, RESOLUTION_640x480, MySnake[0].Pindex, SIZE_SNAKE, SIZE_SNAKE, SQR_COLOR);

			int check = 1;
			do {
				position = ToPindex(((rand()%59 + 3)*10), ((rand()%43 + 3)*10));
				check = checkGen(MySnake, position);
			} while (check);

			DrawARandomNode(position);
			hit = 0;
		}
		else if (hit == 2)
		{
			movex = 0;
			movey = 0;
		}
		}
	}
}

unsigned long ABS2(unsigned long x, unsigned long y)
{
	return	(x < y)? (y-x) : (x-y);
}

static void HitCheckTask( void *pvParameters ){

	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 50 );
	xLastWakeTime = xTaskGetTickCount();

	for( ;; )
	{
		if (xTaskGetTickCount() - xLastWakeTime > xPeriod) {
			xLastWakeTime = xTaskGetTickCount();
		}

		if (hit == 0 && (ABS2(MySnake[0].Pindex , position))%640 < SIZE_SNAKE && (ABS2(MySnake[0].Pindex , position))/640 < SIZE_SNAKE)
		{
			Size++;
			Score++;

			MySnake[Size].Pindex = MySnake[Size - 1].Pindex;
			MySnake[Size].Dim = SIZE_SNAKE;

			hit = 1;
			xSemaphoreGive(GameOver_signal);

		}
		else
		{
			if (hit != 2)
				hit = checkHit(MySnake);
			if (hit == 2)
			{
				movex = 0;
				movey = 0;
			} else {
				xSemaphoreGive(GameOver_signal);

			}
		}

		vTaskDelayUntil( &xLastWakeTime, xPeriod );
	}
}

int checkGen(struct Dino * p, unsigned long pixel)
{
	int hit = 0;
	for (int i = 0; i < Size; i++)
	{
		if(p[i].Pindex == pixel)
		{
			hit = 1;
		}
	}
	return hit;
}

int checkHit(struct Dino * p)
{
	int hit = 0;
	for (int i = 1; i < Size; i++)
	{
		if((p[0].Pindex + (movex + movey*640)) == p[i].Pindex)
		{
			hit = 2;
		}
	}

	if (p[0].Pindex >= 640*20 && p[0].Pindex <= (640*20 + 639) && movey < 0)
	{
		hit = 2;
	}

	if ((p[0].Pindex + 640*SIZE_SNAKE) <= (640*460 + 639) && (p[0].Pindex + 640*SIZE_SNAKE) >= 640*460 && movey > 0)
	{
		hit = 2;
	}

	if (p[0].Pindex%640 <= 20 && movex < 0)
	{
		hit = 2;
	}

	if (p[0].Pindex%640 >= (620 - SIZE_SNAKE) && movex > 0)
	{
		hit = 2;
	}

	return hit;
}

void drawScore(int number, int xPosition, int yPosition)
{
	unsigned int pixel = ToPindex(xPosition, yPosition);
	int valueArray1[5] = {0b1101101, 0b0111001, 0b0111111, 0b1110111, 0b1111001};
	int value2 = valueArray1[number];

	if (value2 & 0x01)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + edgeNumber, widthNumber, edgeNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + edgeNumber, widthNumber, edgeNumber, val_bound);
	}

	if (value2 & 0x02)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, edgeNumber), edgeNumber, heightNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, edgeNumber), edgeNumber, heightNumber, val_bound);
	}

	if (value2 & 0x04)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, val_bound);
	}

	if (value2 & 0x08)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber*2 + edgeNumber*2)), widthNumber, edgeNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber*2 + edgeNumber*2)), widthNumber, edgeNumber, val_bound);
	}

	if (value2 & 0x10)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, val_bound);
	}

	if (value2 & 0x20)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, edgeNumber), edgeNumber, heightNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, edgeNumber), edgeNumber, heightNumber, val_bound);
	}

	if (value2 & 0x40)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber + edgeNumber)), widthNumber, edgeNumber, 0xff00ff);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber + edgeNumber)), widthNumber, edgeNumber, val_bound);
	}
}

static void vSetupGPIOInterrupt( ){
	portBASE_TYPE xStatus;
	XGpio_Initialize(&Gpio, GPIO_DEVICE_ID);
	xStatus = xPortInstallInterruptHandler( XPAR_INTC_0_GPIO_0_VEC_ID, vButtonReadISR, NULL );
	if( xStatus == pdPASS )
	{
		vPortEnableInterrupt( XPAR_INTC_0_GPIO_0_VEC_ID);
		XGpio_InterruptEnable( &Gpio, ulGPIOInputChannel );
		XGpio_InterruptGlobalEnable( &Gpio );
	}
}

static void vButtonReadISR()
{
	long button_task = 0;
	xSemaphoreGiveFromISR(Button_signal, &button_task);
	XGpio_InterruptClear( &Gpio, ulGPIOInputChannel );
	portYIELD_FROM_ISR( button_task );

}

void scoreNumber(int  number, int xPosition, int yPosition)
{
	unsigned int pixel = ToPindex(xPosition, yPosition);
	int value;
	int valueArray[10] = {0b0111111, 0b0000110, 0b1011011, 0b1001111, 0b1100110, 0b1101101, 0b1111101, 0b0000111, 0b1111111, 0b1101111};
	value = valueArray[number];


	if (value & 0x01)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + edgeNumber, widthNumber, edgeNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + edgeNumber, widthNumber, edgeNumber, val_bound);
	}

	if (value & 0x02)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, edgeNumber), edgeNumber, heightNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, edgeNumber), edgeNumber, heightNumber, val_bound);
	}

	if (value & 0x04)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber + widthNumber, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, val_bound);
	}

	if (value & 0x08)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber*2 + edgeNumber*2)), widthNumber, edgeNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber*2 + edgeNumber*2)), widthNumber, edgeNumber, val_bound);
	}

	if (value & 0x10)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, (heightNumber + edgeNumber*2)), edgeNumber, heightNumber, val_bound);
	}

	if (value & 0x20)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, edgeNumber), edgeNumber, heightNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(0, edgeNumber), edgeNumber, heightNumber, val_bound);
	}

	if (value & 0x40)
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber + edgeNumber)), widthNumber, edgeNumber, 0xff1000);
	}
	else
	{
		DrawARectMemcpy(0, RESOLUTION_640x480, pixel + ToPindex(edgeNumber, (heightNumber + edgeNumber)), widthNumber, edgeNumber, val_bound);
	}
}

#if(ENABLE_TIMER == 1)
/*-----------------------------------------------------------*/
static void vTimerCallback( TimerHandle_t pxTimer )
{
	long lTimerId;
	configASSERT( pxTimer );
	lTimerId = ( long ) pvTimerGetTimerID( pxTimer );
	if (lTimerId != TIMER_ID) {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}
}
#endif
void init_game(){
	hit = 0;
	Size = 3;
	Score = 0;
	SPEED = 10;
	movex = 0;
	movey = 0;

	for (int i = 0; i < Size; i++)
	{
		MySnake[i].Pindex = ToPindex(WEIGHT_WINDOW/2 + SIZE_SNAKE*i, HEIGHT_WINDOW/2);
		MySnake[i].Dim = SIZE_SNAKE;
	}

	position = ToPindex(((rand()%59 + 3)*10), ((rand()%43 + 3)*10));
	DrawARandomNode(position);

	for (int i = 0; i < Size; i++)
		DrawARectMemcpy(frame_index, RESOLUTION_640x480, MySnake[i].Pindex, SIZE_SNAKE, SIZE_SNAKE, SQR_COLOR);

	scoreNumber((Score)/10, 320, 0);
	scoreNumber((Score)%10, 333, 0);

	for (int i = 0; i < 5; i++)
	{
		drawScore(i, 250 + i*13, 0);
	}

	DrawARectMemcpy(0, RESOLUTION_640x480, 257+5*640, 2, 2, val_bound);
	DrawARectMemcpy(0, RESOLUTION_640x480, 257+15*640, 2, 2, val_bound);
}

void DrawARandomNode(int position){
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	srand(xLastWakeTime);
	DrawARectMemcpy(0, RESOLUTION_640x480, position, SIZE_SNAKE, SIZE_SNAKE, Color[rand() % 7]);
}
#endif
